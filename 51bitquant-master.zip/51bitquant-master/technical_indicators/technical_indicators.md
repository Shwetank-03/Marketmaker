# technical indicator 技术分析指标

1. 什么是技术指标.



## 学习资料

 1. 各种指标的计算公式以及统计的含义.
 1.1 https://school.stockcharts.com/doku.php?id=technical_indicators

 1.2 https://www.barchart.com/education/technical-indicators

 比如MA指标，Moving Average
 https://school.stockcharts.com/doku.php?id=technical_indicators:moving_averages

 如BBands
 https://www.barchart.com/education/technical-indicators/bollinger_bands


## 如何计算技术指标

### 使用Ta-Lib

github地址：官方文档 https://github.com/mrjbq7/ta-lib
使用具体使用

### 结合pandas 计算

### Ta-Lib计算结果和交易所的数据结果不同原因
 1. 数据可能有问题  # ema
 2. 时间不一致
 3. 计算指标的参数不一致
 4. Ta-Lib的算法和交易所的算法不一样


## tradingView 简单介绍
如何写技术指标，研究行情.


