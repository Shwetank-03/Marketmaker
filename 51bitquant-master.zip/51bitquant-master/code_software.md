# 课程相应的代码下载和软件下载链接


## 收费课程的代码下载链接:
https://share.weiyun.com/88xtdom2

## youtube公开课的代码下载链接地址:
https://github.com/51bitquant/51bitquant

## 手动交易下单软件下载链接:
https://share.weiyun.com/F03qTiin

## howtrader 安装包下载链接:
https://share.weiyun.com/LhKEc3cQ

## howtrader代码仓库
https://github.com/51bitquant/howtrader

## vnpy课程的代码下载地址
https://github.com/51bitqunat/course_codes


## 联系方式
如果遇到需要咨询的问题或者定制化开发，可以联系我微信: bitquant51




